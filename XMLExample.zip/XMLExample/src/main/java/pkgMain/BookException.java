package pkgMain;

public class BookException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookException() {
	}
}
